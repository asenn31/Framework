<?php 
/**
 * Konfigurasi dari sistem 
 */

//  APPROOT
define('APPROOT', dirname(dirname(__FILE__)));

// URLROOT
define('URLROOT', 'http://localhost/Framework');

// nama situs
define('SITENAME', 'Random Kost Samarinda');

// tanggal
define('DATE', date("Y-m-d"));

// Konfigurasi Database
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'random_kost');





