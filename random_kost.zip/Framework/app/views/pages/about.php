<?php require_once APPROOT.'/views/inc/header.php'; ?>

<div class="jumbotron text-center">
  <h1 class="display-3 ">About System</h1>
  <hr class="my-4">
  <p class="lead">Created By: <br> <em>Iswanto Taufik Arifin <br> Zanu Alfandi Kamil <br> Anjelda Stevanie </em></p>
  <p>Date : 15 November 2020</p>
</div>

<?php require_once APPROOT.'/views/inc/footer.php'; ?>
