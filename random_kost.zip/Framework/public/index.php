<?php 

// Hubungkan ke Bootstrap di app
require_once '../app/bootstrap.php';

// Buat object Core
$init = new Core;